import java.util.ArrayList;
import java.util.Random;

/**
 * Represents a game scenario including connected rooms and items
 * 
 * @author Cara Tang
 * @version 2013.02.16
 */
public class Scenario
{
    private ArrayList<Room> rooms;
    private Room startRoom;
    private Random random;

    /**
     * Constructor for objects of class Scenario
     */
    public Scenario()
    {
        random = new Random();
        
        // Set up your rooms, exits, and items
        // Move code from Game.createRooms here
        

        // Set the start room


        // Create the rooms ArrayList and add all your rooms to it

    }

    /**
     * @return  the start room for this scenario
     */
    public Room getStartRoom()
    {
        // complete this method
    }
    
    /**
     * @return  a random room from this scenario
     */
    public Room getRandomRoom()
    {
        // complete this method
    }
}
